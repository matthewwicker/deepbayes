# deepbayes
Optimizers for performing approximate Bayesian inference on neural network parameters with Tensorflow and JAX
